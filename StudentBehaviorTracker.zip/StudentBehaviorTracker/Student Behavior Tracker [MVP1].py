import json
from datetime import datetime, timedelta, date
import ttkbootstrap as ttkb
from ttkbootstrap.constants import *
from tkinter import ttk, messagebox, simpledialog, filedialog, scrolledtext
import tkinter as tk  # Still used for Canvas, PhotoImage, etc.
from PIL import Image, ImageTk
import calendar


DEFAULT_SCHEDULES = {
    "5th": {
        "Trimester 1": {
            "A": {1: "Language and Literacy (L&L)", 2: "Mathematics", 3: "Science", 4: "Art", 5: "Gym", 6: "World Language (Spanish)", 7: "Tech Ed"},
            "B": {1: "Science", 2: "Art", 3: "Mathematics", 4: "Health", 5: "Library Research", 6: "Music", 7: "Instructional Technology"},
            "C": {1: "Social Studies/Civics", 2: "Theatre", 3: "Band", 4: "Chorus", 5: "Gym", 6: "Skills(WIN)", 7: "Mandarin"},
            "D": {1: "Language and Literacy (L&L)", 2: "World Language (French)", 3: "Mathematics", 4: "Science", 5: "Art", 6: "Tech Ed", 7: "Health"},
            "E": {1: "Instructional Technology", 2: "Music", 3: "Social Studies/Civics", 4: "Band", 5: "Chorus", 6: "Skills(WIN)", 7: "Mandarin"},
            "T": {1: "Language and Literacy (L&L)", 2: "Mathematics", 3: "Science", 4: "Art", 5: "Gym", 6: "World Language (Spanish)", 7: "Library Research"}
        },
        # Add "Trimester 2", "Trimester 3" as needed...
    },
    # You can add other grades here!
}

DARK_NAVY = "#1A2238"
BRIGHT_RED = "#E94560"
WHITE = "#FFFFFF"
LETTER_DAYS = ["A", "B", "C", "D", "E", "T"]
START_DATE = date(2024, 9, 3)  # <-- Set this to your district's first school day
LETTER_DAY_OVERRIDES = {}  # Dictionary for manual overrides (date string: letter day)

def get_current_letter_day():
    today = datetime.today().date()
    day_count = 0
    date_iter = START_DATE
    while date_iter <= today:
        if date_iter.weekday() < 5:  # Only count weekdays
            day_count += 1
        date_iter += timedelta(days=1)
    letter_index = (day_count - 1) % len(LETTER_DAYS)
    return LETTER_DAYS[letter_index]


def skip_weekends(d):
    """Advance date to the next weekday if it's a weekend."""
    while d.weekday() >= 5:  # 5 = Saturday, 6 = Sunday
        d += timedelta(days=1)
    return d

def calculate_letter_day(target_date=None):
    """
    Returns the correct letter day (A, B, C, D, E, T) for today or a given date,
    skipping weekends and accounting for manual overrides.
    """
    if target_date is None:
        today = date.today()
    elif isinstance(target_date, str):
        today = datetime.strptime(target_date, "%Y-%m-%d").date()
    else:
        today = target_date

    # Check for override first
    date_str = today.strftime("%Y-%m-%d")
    if date_str in LETTER_DAY_OVERRIDES:
        return LETTER_DAY_OVERRIDES[date_str]

    # Calculate relative to START_DATE
    d = START_DATE
    letter_day_index = 0
    while d < today:
        d += timedelta(days=1)
        if d.weekday() < 5:  # Only advance on weekdays (Mon-Fri)
            letter_day_index = (letter_day_index + 1) % len(LETTER_DAYS)
    return LETTER_DAYS[letter_day_index]

def set_letter_day_override(date_string, letter_day=None):
    """
    Manually set or remove a letter day override for a specific date.
    Use None to remove the override.
    Example: set_letter_day_override('2024-09-10', 'C')
    """
    if letter_day:
        LETTER_DAY_OVERRIDES[date_string] = letter_day
    elif date_string in LETTER_DAY_OVERRIDES:
        del LETTER_DAY_OVERRIDES[date_string]

TRIMESTERS = {
    "Trimester 1": ("09-01", "12-01"),
    "Trimester 2": ("12-02", "03-15"),
    "Trimester 3": ("03-16", "06-30")
}

def get_current_trimester():
    today = datetime.today()
    current = today.strftime("%m-%d")
    for name, (start, end) in TRIMESTERS.items():
        if start <= end:
            if start <= current <= end:
                return name
        else:
            if current >= start or current <= end:
                return name
    return "Unknown"

REQUIRED_CLASSES = [
    "Language & Literacy", "Math", "Science", "SocialStudies/Civics", "Gym",
    "Library Research", "Tech Ed", "Instructional Technology", "World Language",
    "Art", "Chorus", "Band", "Skills(WIN)", "Theatre"
]

class Student:
    def __init__(self, name, grade, age=None, goals=None, program=None, image_path=None, summary="", dob=""):
        # ...existing fields...
        self.name = name
        self.grade = grade
        self.age = age
        self.goals = goals or ""
        self.program = program
        self.image_path = image_path
        self.summary = summary or ""
        self.dob = dob
        self.classes = {}   # Keep for general, non-letter-day classes
        self.weekly_todos = []
        self.behavior_log = []
        self.pinned = False
        self.custom_schedule = {}  # << NEW: for custom overrides

    # ...existing methods...

    def get_class_for(self, trimester, letter_day, period):
        # Custom override first, else default, else Not Assigned
        return (
            self.custom_schedule.get(trimester, {}).get(letter_day, {}).get(period)
            or DEFAULT_SCHEDULES.get(self.grade, {}).get(trimester, {}).get(letter_day, {}).get(period, "Not Assigned")
        )

    def set_class_for(self, trimester, letter_day, period, class_name):
        if trimester not in self.custom_schedule:
            self.custom_schedule[trimester] = {}
        if letter_day not in self.custom_schedule[trimester]:
            self.custom_schedule[trimester][letter_day] = {}
        self.custom_schedule[trimester][letter_day][period] = class_name

    def get_classes_for_trimester(self, trimester):
        classes = set()
        # Add classes from defaults
        grade_sched = DEFAULT_SCHEDULES.get(self.grade, {}).get(trimester, {})
        for day_sched in grade_sched.values():
            classes.update(day_sched.values())
        # Add custom overrides
        for day_sched in self.custom_schedule.get(trimester, {}).values():
            classes.update(day_sched.values())
        return list(classes)


    def add_behavior(self, description, behavior_type, is_positive, period):
        entry = {
            "description": description,
            "type": behavior_type,
            "positive": is_positive,
            "period": period,
            "timestamp": datetime.now().strftime("%Y-%m-%d")
        }    
        self.behavior_log.append(entry)

    def summarize_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        positives = sum(1 for entry in self.behavior_log if entry["timestamp"] == today and entry["positive"])
        negatives = sum(1 for entry in self.behavior_log if entry["timestamp"] == today and not entry["positive"])
        return {"positive": positives, "negative": negatives}

    def weekly_trend(self):
        today = datetime.now()
        last_7_days = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
        trend = {day: {"positive":0, "negative": 0} for day in last_7_days}
        for entry in self.behavior_log:
            if entry["timestamp"] in trend:
                if entry["positive"]:
                    trend[entry["timestamp"]]["positive"] += 1
                else:
                    trend[entry["timestamp"]]["negative"] += 1
        return trend

    def period_summary(self):
        periods = {i: {"positive": 0, "negative": 0} for i in range(1, 8)}
        for entry in self.behavior_log:
            if entry["period"] in periods:
                if entry["positive"]:
                    periods[entry["period"]]["positive"] += 1
                else:
                    periods[entry["period"]]["negative"] += 1
        return periods

    def set_classes_for_trimester(self, trimester, class_list):
        """
        Set the list of classes for a given trimester (overwrite any existing).
        `class_list` should be a list of strings, e.g. ["Math", "Science", ...]
        """
        if trimester not in self.classes:
            self.classes[trimester] = []
        self.classes[trimester] = class_list

    def get_classes_for_trimester(self, trimester):
        # Returns a list of classes for a trimester, or an empty list
        # Backward compatible: support old dict structure for legacy data
        classes = self.classes.get(trimester, [])
        if isinstance(classes, dict):  # Legacy support
            # flatten values for all periods or letter days
            found = set()
            for v in classes.values():
                if isinstance(v, dict):
                    found.update(v.values())
                elif isinstance(v, list):
                    found.update(v)
                elif isinstance(v, str):
                    found.add(v)
            return list(found)
        return list(classes)

    def set_classes_for_trimester(self, trimester, classes):
        # Save as a list
        self.classes[trimester] = list(classes)


        # Add any more methods as needed, e.g., for saving/loading data, etc.

        
class BehaviorTracker:
    def __init__(self):
        self.students = {}
        self.my_students = []
        self.last_update = None

    def add_student(self, name, grade, age=None, goals="", program=None, image_path=None):
        self.students[name] = Student(name, grade, age, goals, program, image_path)


    def record_behavior(self, student_name, description, behavior_type, is_positive, period, class_subject=None, letter_day="A", timestamp=None):
        if student_name not in self.students:
            return

        student = self.students[student_name]
        current_trimester = get_current_trimester()

        # Look up class subject if not provided
        if not class_subject:
            class_subject = student.classes.get(current_trimester, {}).get(letter_day, {}).get(period, "Unknown")

        entry = {
            "timestamp": timestamp or datetime.now().strftime("%Y-%m-%d"),
            "description": description,
            "type": behavior_type,
            "positive": is_positive,
            "period": period,
            "class": class_subject,
            "letter_day": letter_day
        }
        student.behavior_log.append(entry)
        self.save_data()


    def add_to_my_students(self, name):
        if name in self.students and name not in self.my_students:
            self.my_students.append(name)

    def remove_from_my_students(self, name):
        if name in self.my_students:
            self.my_students.remove(name)

    def get_my_students(self):
        return [self.students[name] for name in self.my_students if name in self.students]


    def get_student_log(self, name):
        return self.students[name].behavior_log if name in self.students else []

    def summarize_student_behavior_by_date(self, name, date):
        student = self.students.get(name)
        if not student:
            return None
        positives = sum(1 for entry in student.behavior_log if entry["timestamp"] == date and entry["positive"])
        negatives = sum(1 for entry in student.behavior_log if entry["timestamp"] == date and not entry["positive"])
        return {"positive": positives, "negative": negatives}

    def summarize_today_by_period(self):
        today = datetime.now().strftime("%Y-%m-%d")
        summary = {i: {"positive": 0, "negative": 0} for i in range(1, 8)}

        for student in self.students.values():
            for entry in student.behavior_log:
                if entry["timestamp"] == today:
                    period = entry["period"]
                    if entry["positive"]:
                        summary[period]["positive"] += 1
                    else:
                        summary[period]["negative"] += 1

        return summary


    def save_data(self):
        student_data = {}
        for name, student in self.students.items():
            student_data[name]= {
                "grade": student.grade,
                "age": student.age,
                "goals": student.goals,
                "classes": student.classes,  # <--- now dict of trimester: list
                "weekly_todos": student.weekly_todos,
                "behavior_log": student.behavior_log,
                "program": student.program,
                "summary": student.summary,
                "dob": getattr(student, "dob", ""),
                "image_path": student.image_path,
                "pinned": getattr(student, "pinned", False)
            }
        data = {
            "students": student_data,
            "my_students": self.my_students,
            "last_update": self.last_update
        }
        with open("students_data.json", "w") as f:
            json.dump(data, f, indent=4)


    def load_data(self):
        try:
            with open("students_data.json", "r") as f:
                data = json.load(f)
            student_info = data.get("students", {})
            for name, info in student_info.items():
                student = Student(
                    name=name,
                    grade=info["grade"],
                    age=info.get("age"),
                    goals=info.get("goals"),
                    program=info.get("program"),
                    image_path=info.get("image_path", ""),
                    summary=info.get("summary", ""),
                    dob=info.get("dob", "")
                )
                student.weekly_todos = info.get("weekly_todos", [])
                student.behavior_log = info.get("behavior_log", [])
                student.classes = info.get("classes", {})  # now expects dict of trimester: list
                student.pinned = info.get("pinned", False)
                self.students[name] = student
            self.my_students = data.get("my_students", [])
            self.last_update = data.get("last_update", None)
            # yearly update logic unchanged
        except FileNotFoundError:
            self.students = {}
            self.my_students = []
            self.last_update = None

    def should_run_yearly_update(self):
            """Check if a new school year has started since last update."""
            if not self.last_update:
                return True  # first time loading

            last = datetime.strptime(self.last_update, "%Y-%m-%d")
            today = datetime.today()

            # Assuming school year rolls over on September 1st
            last_year = last.year if last.month >= 9 else last.year - 1
            current_year = today.year if today.month >= 9 else today.year - 1

            return current_year > last_year

    def run_yearly_update(self):
        """Automatically age and promote students."""
        for student in self.students.values():
            # Age update
            if student.dob:
                try:
                    dob = datetime.strptime(student.dob, "%Y-%m-%d")
                    student.age = str(int(student.age) + 1)
                except:
                    pass  # ignore invalid DOB or age format

            # Grade promotion
            grade_order = ["5th", "6th", "7th", "8th"]
            if student.grade in grade_order[:-1]:
                next_index = grade_order.index(student.grade) + 1
                student.grade = grade_order[next_index]

        self.last_update = datetime.today().strftime("%Y-%m-%d")



class BehaviorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("NPS Student Behavior Tracker")
        self.root.geometry("900x600")
        self.root.config(bg="#121212")

        self.tracker = BehaviorTracker()
        self.tracker.load_data()

        self.pinned_students = set()
        self.current_letter_day = self.load_letter_day()
        self.is_admin = False  # Track if admin is logged in

        # Configure root layout
        self.root.rowconfigure(1, weight=1)  # Main content row
        self.root.columnconfigure(0, weight=1)

        # === Navigation Bar (row 0) ===
        self.nav_bar = ttkb.Frame(root, height=60)
        self.nav_bar.grid(row=0, column=0, sticky="ew")

        logo_image = Image.open("logo.png").resize((50, 50))
        self.logo = ImageTk.PhotoImage(logo_image)
        logo_label = ttkb.Label(self.nav_bar, image=self.logo, bootstyle="dark")
        logo_label.pack(side="left", padx=15, pady=5)

        app_name = ttkb.Label(self.nav_bar, text="NPS Student Behavior Tracker",
                              font=("Helvetica", 18, "bold"), foreground="white")
        app_name.pack(side="left")

        nav_buttons = [
            ("Dashboard", self.show_dashboard),
            ("Add Student", self.show_add_student),
            ("Student Hub", self.show_student_hub),
            ("My Students", self.show_my_students),
            ("Full Log Viewer", self.show_all_behavior_logs)
        ]

        if self.is_admin:
            nav_buttons += [("Reports", self.show_reports), ("Settings", self.show_settings)]
        nav_buttons += [("Logout", self.logout)]

        for text, command in reversed(nav_buttons):
            bootstyle = "danger" if text == "Logout" else "primary"
            ttkb.Button(self.nav_bar, text=text, command=command, bootstyle=bootstyle).pack(side="right", padx=12, pady=10)

        # === Main Content Area (row 1) ===
        self.main_content = ttkb.Frame(root)
        self.main_content.grid(row=1, column=0, sticky="nsew")
        self.root.rowconfigure(1, weight=1)

        # Show login screen initially
        self.show_login()

    def show_login(self):
        login_win = tk.Toplevel(self.root)
        login_win.title("Login")
        login_win.geometry("350x210")
        login_win.grab_set()
        login_win.focus_set()

        ttkb.Label(login_win, text="Username:").pack(pady=(15, 0))
        username_var = tk.StringVar()
        ttkb.Entry(login_win, textvariable=username_var).pack()

        ttkb.Label(login_win, text="Passcode:").pack(pady=(10, 0))
        password_var = tk.StringVar()
        ttkb.Entry(login_win, textvariable=password_var, show="*").pack()

        msg = ttkb.Label(login_win, text="", foreground="red")
        msg.pack(pady=5)

        def attempt_login():
            username = username_var.get().strip()
            password = password_var.get().strip()
            # Set your allowed logins here
            if (username == "nps" and password == "1234"):
                self.is_admin = False
            elif (username == "npsadmin" and password == "9999"):
                self.is_admin = True
            else:
                msg.config(text="Invalid credentials.")
                return
            login_win.destroy()
            self.show_dashboard()

        ttkb.Button(login_win, text="Login", bootstyle="primary", command=attempt_login).pack(pady=15)

    def load_letter_day(self):
        """Load the current letter day from settings.json, default to 'A'."""
        try:
            if os.path.exists("settings.json"):
                with open("settings.json", "r") as f:
                    data = json.load(f)
                    return data.get("current_letter_day", "A")
        except:
            pass
        return "A"

    def save_letter_day(self):
        """Save the current letter day to settings.json."""
        try:
            data = {"current_letter_day": self.current_letter_day}
            with open("settings.json", "w") as f:
                json.dump(data, f)
        except Exception as e:
            print("Failed to save letter day:", e)

    def set_letter_day(self, new_day):
        """Set and save the letter day, then refresh the main view."""
        self.current_letter_day = new_day
        self.save_letter_day()
        self.refresh_all_views()

    def refresh_all_views(self):
        """Refresh the main content area. You can expand this as needed."""
        self.show_dashboard()
    

    def clear_main_content(self):
        for widget in self.main_content.winfo_children():
            widget.destroy()

    def show_trimester_class_entry(self, student_name):
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        trimester = get_current_trimester()

        entry_win = tk.Toplevel(self.root)
        entry_win.title(f"{student_name} – {trimester} Classes")
        entry_win.geometry("500x600")

        ttkb.Label(entry_win, text=f"Enter {trimester} Class Schedule", font=("Helvetica", 14, "bold")).pack(pady=10)

        form_frame = ttkb.Frame(entry_win)
        form_frame.pack(fill="both", expand=True, padx=10, pady=10)

        class_vars = {}
        for subject in REQUIRED_CLASSES:
            ttkb.Label(form_frame, text=subject + ":").pack(anchor="w", pady=(5, 0))
            var = tk.StringVar()
            entry = ttkb.Entry(form_frame, textvariable=var)
            entry.pack(fill="x", pady=2)
            class_vars[subject] = var

        def save_schedule():
            if trimester not in student.classes:
                student.classes[trimester] = {}
            student.classes[trimester][letter_day_var.get()] = {subj: var.get().strip() for subj, var in class_vars.items() if var.get().strip()}
            self.tracker.save_data()
            entry_win.destroy()
            messagebox.showinfo("Success", f"{trimester} classes saved for {student.name}.")

        ttkb.Button(entry_win, text="Save Classes", bootstyle="success", command=save_schedule).pack(pady=15)
        ttkb.Button(entry_win, text="Cancel", bootstyle="secondary", command=entry_win.destroy).pack()

    def show_dashboard(self):
        # ---- [Define styles if not already set globally] ----
        # Place this at the start of show_dashboard, or ideally at the top-level of your app after importing ttkbootstrap
        style = ttkb.Style()
        DARK_NAVY = "#182747"  # or whatever dark navy hex you want
        style.configure("TopRow.TFrame", background=DARK_NAVY)

        self.clear_main_content()

        dashboard_frame = ttkb.Frame(self.main_content)
        dashboard_frame.pack(fill="both", expand=True, padx=20, pady=20)

        # 1. HEADER — styled to match "danger"/red
        top_row = ttkb.Frame(dashboard_frame, style="TopRow.TFrame")
        top_row.pack(fill="x", pady=(0, 24))
        top_row.config(height=48)
        top_row.pack_propagate(False)

        # Use a 3-column grid for perfect placement
        top_row.columnconfigure(0, weight=1)
        top_row.columnconfigure(1, weight=2)
        top_row.columnconfigure(2, weight=1)

        # Dashboard label (left)
        dashboard_label = ttkb.Label(
            top_row, text="📊 Dashboard",
            font=("Helvetica", 18,),
            foreground="white",
            background=DARK_NAVY
        )
        dashboard_label.grid(row=0, column=0, sticky="w", padx=(8, 0))

        # Student First (centered app name)
        app_name_label = ttkb.Label(
            top_row, text="Student First",
            font=("Helvetica", 20),
            foreground="white",
            background=DARK_NAVY
        )
        app_name_label.grid(row=0, column=1, sticky="n", pady=(0, 2))

        # Letter Day (right)
        letter_day = get_current_letter_day()
        letter_day_label = ttkb.Label(
            top_row, text=f"Letter Day: {letter_day}",
            font=("Helvetica", 18),
            foreground="white",
            background=DARK_NAVY
        )
        letter_day_label.grid(row=0, column=2, sticky="e", padx=(0, 12))

        # Spacer for alignment
        top_row.pack_propagate(False)

        # ---- [Dashboard Cards Grid] ----
        grid = ttkb.Frame(dashboard_frame)
        grid.pack(fill="both", expand=True)
        grid.columnconfigure((0, 1), weight=1)
        grid.rowconfigure((0, 1), weight=1)

        card_style = {"padding": 20}

        # Top Left Card - Total Students
        top_left = ttkb.LabelFrame(grid, text="👥 Total Students", **card_style, bootstyle="danger")
        top_left.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        ttkb.Label(
            top_left,
            text=str(len(self.tracker.students)),
            font=("Helvetica", 28, "bold"),
            foreground="#FFFFFF"
        ).pack(anchor="center", pady=8)

        # Top Right Card - Daily Summary (P/N not emojis)
        top_right = ttkb.LabelFrame(grid, text="📆 Daily Summary", **card_style, bootstyle="primary")
        top_right.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        today = datetime.now().strftime("%Y-%m-%d")
        total_positive, total_negative = 0, 0
        for student in self.tracker.students.values():
            for entry in student.behavior_log:
                if entry["timestamp"] == today:
                    if entry["positive"]:
                        total_positive += 1
                    else:
                        total_negative += 1
        # P = Positive, N = Negative
        ttkb.Label(
            top_right,
            text=f"P: {total_positive}   N: {total_negative}",
            font=("Helvetica", 24, "bold"),
            foreground="#FFFFFF"
        ).pack(anchor="center", pady=8)

        # Bottom Left Card - Top Performer
        bottom_left = ttkb.LabelFrame(grid, text="🏅 Top Performer", **card_style, bootstyle="primary")
        bottom_left.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        top_student = None
        top_score = 0
        for student in self.tracker.students.values():
            pos_today = sum(1 for e in student.behavior_log if e["timestamp"] == today and e["positive"])
            if pos_today > top_score:
                top_student = student.name
                top_score = pos_today
        if top_student:
            ttkb.Label(
                bottom_left,
                text=f"{top_student}\nP: {top_score} Positives",
                font=("Helvetica", 16, "bold"),
                foreground="#FFFFFF"
            ).pack(anchor="center", pady=8)
        else:
            ttkb.Label(
                bottom_left,
                text="No data yet",
                font=("Helvetica", 14),
                foreground="#CCCCCC"
            ).pack(anchor="center", pady=8)

        # Bottom Right Card - Behavior Log Access
        bottom_right = ttkb.LabelFrame(grid, text="📝 Logs Access", **card_style, bootstyle="primary")
        bottom_right.grid(row=1, column=1, sticky="nsew", padx=10, pady=10)
        ttkb.Button(bottom_right, text="View All Logs", bootstyle="info", command=self.show_student_hub, width=20).pack(pady=12)

        # (New) Bottom Row Card – Daily Period Summary (P/N and period text not bold, just larger)
        period_summary_card = ttkb.LabelFrame(grid, text="🕐 Daily Period Summary", **card_style, bootstyle="info")
        period_summary_card.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=10, pady=10)
        period_summary = self.tracker.summarize_today_by_period()
        for period in range(1, 8):
            p = period_summary[period]
            ttkb.Label(
                period_summary_card,
                text=f"Period {period}:  P: {p['positive']}   N: {p['negative']}",
                font=("Helvetica", 16),  # Large, but not bold
                foreground="#FFFFFF"
            ).pack(anchor="w", padx=8)



    def show_add_student(self):
        self.clear_main_content()
        form_frame = ttkb.Frame(self.main_content)
        form_frame.pack(pady=20, padx=20, fill="both", expand=True)

        ttkb.Label(form_frame, text="Add New Student", foreground="#FFFFFF", font=("Helvetica", 16, "bold")).pack(pady=10)

        ttkb.Label(form_frame, text="Name:", foreground="#FFFFFF").pack(anchor="w")
        name_entry = ttkb.Entry(form_frame)
        name_entry.pack(fill="x", pady=5)

        ttkb.Label(form_frame, text="Grade (5th–8th):", foreground="#FFFFFF").pack(anchor="w")
        grade_entry = ttkb.Combobox(form_frame, values=["5th", "6th", "7th", "8th"], state="readonly")
        grade_entry.pack(fill="x", pady=5)

        ttkb.Label(form_frame, text="Age:", foreground="#FFFFFF").pack(anchor="w")
        age_entry = ttkb.Entry(form_frame)
        age_entry.pack(fill="x", pady=5)

        ttkb.Label(form_frame, text="Program (Compass / Access):", foreground="#FFFFFF").pack(anchor="w")
        program_dropdown = ttkb.Combobox(form_frame, values=["", "Compass", "Access"], state="readonly")
        program_dropdown.pack(fill="x", pady=5)

        ttkb.Label(form_frame, text="IEP Goals / Behavior Plans:", foreground="#FFFFFF").pack(anchor="w")
        goals_entry = tk.Text(form_frame, height=4)
        goals_entry.pack(fill="both", pady=5)

        image_path_var = tk.StringVar()

        def upload_image():
            path = filedialog.askopenfilename(filetypes=[("Image files", "*.png *.jpg *.jpeg")])
            if path:
                image_path_var.set(path)
                messagebox.showinfo("Success", "Image selected!")

        def submit_student():
            name = name_entry.get().strip()
            grade = grade_entry.get().strip()
            age = age_entry.get().strip()
            program = program_dropdown.get().strip()
            goals = goals_entry.get("1.0", tk.END).strip()
            image_path = image_path_var.get()

            if not name or not grade:
                messagebox.showerror("Error", "Name and Grade are required.")
                return

            self.tracker.add_student(name, grade, age, goals, program, image_path)
            student = self.tracker.students[name]

            self.prompt_class_schedule(student)  # ✅ This will save automatically after

            self.show_student_hub()


        ttkb.Button(form_frame, text="Upload Image", bootstyle="secondary", command=upload_image).pack(pady=5)
        ttkb.Button(form_frame, text="Create Student", bootstyle="primary", command=submit_student).pack(pady=15)

    def prompt_enter_classes(self, student):
        win = tk.Toplevel(self.root)
        win.title(f"Enter Classes – {student.name}")
        win.geometry("400x300")

        ttkb.Label(win, text="Enter Classes for this Trimester",
                   font=("Helvetica", 14, "bold")).pack(pady=10)

        trimester_var = tk.StringVar(value=get_current_trimester())
        ttkb.Label(win, text="Trimester:").pack(pady=(5, 0))
        ttkb.Combobox(win, textvariable=trimester_var, values=list(TRIMESTERS.keys()), state="readonly").pack(fill="x", padx=20)

        class_var = tk.StringVar()
        ttkb.Label(win, text="Classes (comma-separated):").pack(pady=(15, 0))
        class_entry = ttkb.Entry(win, textvariable=class_var)
        class_entry.pack(fill="x", padx=20)

        # If editing, pre-populate
        def load_trimester_classes(*_):
            selected = trimester_var.get()
            class_list = student.classes.get(selected, [])
            if isinstance(class_list, dict):  # Handle legacy format
                all_classes = set()
                for v in class_list.values():
                    if isinstance(v, dict):
                        all_classes.update(v.values())
                    elif isinstance(v, str):
                        all_classes.add(v)
                class_list = list(all_classes)
            class_var.set(", ".join(class_list))

        trimester_var.trace_add("write", load_trimester_classes)
        load_trimester_classes()

        def save_classes_and_close():
            selected = trimester_var.get()
            classes = [c.strip() for c in class_var.get().split(",") if c.strip()]
            student.classes[selected] = classes
            self.tracker.save_data()
            messagebox.showinfo("Success", f"Classes for {selected} saved.")
            win.destroy()
            self.show_student_hub()

        def save_for_later():
            # Save current data, but don't require anything filled out
            win.destroy()
            self.show_student_hub()

        btn_frame = ttkb.Frame(win)
        btn_frame.pack(pady=15)

        ttkb.Button(btn_frame, text="💾 Save Classes", bootstyle="success", command=save_classes_and_close).pack(side="left", padx=10)
        ttkb.Button(btn_frame, text="Save for Later", bootstyle="secondary", command=save_for_later).pack(side="left", padx=10)
        ttkb.Button(btn_frame, text="Cancel", bootstyle="danger", command=win.destroy).pack(side="left", padx=10)
        
    def show_student_hub(self):
        self.clear_main_content()

        # Main container with background
        hub_frame = ttkb.Frame(self.main_content)
        hub_frame.pack(fill="both", expand=True, padx=20, pady=20)
        hub_frame.configure(style="dark.TFrame")  # Make sure your ttkbootstrap theme supports this, or use a dark color directly.

        # HEADER
        header_row = ttkb.Frame(hub_frame)
        header_row.pack(fill="x", pady=(0, 24))

        header_label = ttkb.Label(
            header_row, text="Student Hub",
            font=("Helvetica", 22, "bold"),
            foreground="white"
        )
        header_label.pack(side="left")

        # FILTERS ROW
        filter_row = ttkb.Frame(hub_frame)
        filter_row.pack(fill="x", pady=(0, 18))

        ttkb.Label(
            filter_row, text="Grade:",
            font=("Helvetica", 12, "bold"),
            foreground="white"
        ).pack(side="left", padx=(0, 6))

        grade_var = tk.StringVar(value="All")
        grade_box = ttkb.Combobox(
            filter_row, textvariable=grade_var,
            values=["All", "5th", "6th", "7th", "8th"],
            state="readonly", width=6
        )
        grade_box.pack(side="left", padx=(0, 16))

        ttkb.Label(
            filter_row, text="Program:",
            font=("Helvetica", 12, "bold"),
            foreground="white"
        ).pack(side="left", padx=(0, 6))

        program_var = tk.StringVar(value="All")
        program_box = ttkb.Combobox(
            filter_row, textvariable=program_var,
            values=["All", "Compass", "Access"],
            state="readonly", width=10
        )
        program_box.pack(side="left", padx=(0, 16))

        ttkb.Label(
            filter_row, text="Search:",
            font=("Helvetica", 12, "bold"),
            foreground="white"
        ).pack(side="left", padx=(0, 6))

        search_var = tk.StringVar()
        search_entry = ttkb.Entry(
            filter_row, textvariable=search_var, width=20,
            font=("Helvetica", 12),
            bootstyle="dark"
        )
        search_entry.pack(side="left", padx=(0, 16))

        # --- Student List/Table Section ---
        table_frame = ttkb.Frame(hub_frame)
        table_frame.pack(fill="both", expand=True)

        columns = ("Name", "Grade", "Program", "Actions")
        student_tree = ttkb.Treeview(
            table_frame, columns=columns, show="headings", height=14, selectmode="browse"
        )
        # Style headings
        for col in columns:
            student_tree.heading(col, text=col)
            student_tree.column(col, anchor="center", width=130)

        # Fill treeview with current filtered students (implement update_table for filters/search)
        def update_table(*_):
            for row in student_tree.get_children():
                student_tree.delete(row)
            for student in self.tracker.students.values():
                if (grade_var.get() != "All" and student.grade != grade_var.get()):
                    continue
                if (program_var.get() != "All" and student.program != program_var.get()):
                    continue
                if (search_var.get() and search_var.get().lower() not in student.name.lower()):
                    continue
                student_tree.insert(
                    "", "end",
                    values=(student.name, student.grade, student.program, "View")
                )

        # Initial fill
        update_table()
        grade_var.trace_add("write", update_table)
        program_var.trace_add("write", update_table)
        search_var.trace_add("write", update_table)

        # Style treeview for dark mode
        style = ttk.Style()
        style.configure("Treeview",
                        background="#181f28",  # very dark navy/black
                        fieldbackground="#181f28",
                        foreground="white",
                        rowheight=32,
                        font=("Helvetica", 12))
        style.map('Treeview', background=[('selected', '#20354c')])

        # Pack table
        student_tree.pack(fill="both", expand=True, pady=8)

        # Button for add student at bottom right
        add_btn = ttkb.Button(
            hub_frame, text="➕ Add Student",
            bootstyle="danger", command=self.show_add_student, width=18
        )
        add_btn.pack(side="right", pady=(18, 0))

        # Optional: Double-click to view student portfolio
        def on_double_click(event):
            selected = student_tree.selection()
            if selected:
                name = student_tree.item(selected, "values")[0]
                self.show_student_profile(name)

        student_tree.bind("<Double-1>", on_double_click)

    def show_all_behavior_logs(self):
        self.clear_main_content()

        frame = ttkb.Frame(self.main_content)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ttkb.Label(frame, text="🧾 Full Behavior Log Viewer", font=("Helvetica", 16, "bold"), foreground="white").pack(pady=10)

        grade_var = tk.StringVar(value="All")
        start_date = tk.StringVar()
        end_date = tk.StringVar()
    
        # --- Filters ---
        filters = ttkb.Frame(frame)
        filters.pack(fill="x", pady=10)

        ttkb.Label(filters, text="Student:", foreground="white").grid(row=0, column=0, padx=5)
        student_var = tk.StringVar(value="All")
        student_dropdown = ttkb.Combobox(filters, textvariable=student_var, state="readonly")
        student_dropdown['values'] = ["All"] + list(self.tracker.students.keys())
        student_dropdown.grid(row=0, column=1, padx=5)

        ttkb.Label(filters, text="Grade:", foreground="white").grid(row=0, column=2, padx=5)
        grade_var = tk.StringVar(value="All")
        grade_dropdown = ttkb.Combobox(filters, textvariable=grade_var, values=["All", "5th", "6th", "7th", "8th"], state="readonly")
        grade_dropdown.grid(row=0, column=3, padx=5)

        ttkb.Label(filters, text="Date From:", foreground="white").grid(row=1, column=0, padx=5)
        from_date = ttkb.Entry(filters)
        from_date.grid(row=1, column=1, padx=5)

        ttkb.Label(filters, text="Date To:", foreground="white").grid(row=1, column=2, padx=5)
        to_date = ttkb.Entry(filters)
        to_date.grid(row=1, column=3, padx=5)

        ttkb.Button(frame, text="📤 Export to CSV", bootstyle="primary", command=lambda: export_to_csv()).pack(pady=5)

        log_container = tk.Canvas(frame, highlightthickness=0)
        scrollbar = ttkb.Scrollbar(frame, orient="vertical", command=log_container.yview)
        scrollable_frame = ttkb.Frame(log_container)

        log_container.create_window((0, 0), window=scrollable_frame, anchor="nw")
        log_container.configure(yscrollcommand=scrollbar.set)

        log_container.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        scrollable_frame.bind("<Configure>", lambda e: log_container.configure(scrollregion=log_container.bbox("all")))

        def export_to_csv():
            logs = []
            for student in self.tracker.students.values():
                if grade_var.get() != "All" and student.grade != grade_var.get():
                    continue
                for entry in student.behavior_log:
                    if start_date.get() and entry["timestamp"] < start_date.get():
                        continue
                    if end_date.get() and entry["timestamp"] > end_date.get():
                        continue
                    logs.append({
                        "Student Name": student.name,
                        "Grade": student.grade,
                        "Date": entry["timestamp"],
                        "Period": entry["period"],
                        "Class": entry.get("class", "Unknown"),
                        "Type": entry["type"],
                        "Positive": "Yes" if entry["positive"] else "No",
                        "Description": entry["description"]
                    })

            if not logs:
                messagebox.showinfo("No Data", "No logs match the current filters.")
                return

            filepath = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV Files", "*.csv")])
            if not filepath:
                return

            with open(filepath, "w", newline='') as f:
                writer = csv.DictWriter(f, fieldnames=logs[0].keys())
                writer.writeheader()
                writer.writerows(logs)

            messagebox.showinfo("Exported", f"Logs exported to {filepath}")

        def apply_filters():
            # Clear current logs
            for widget in scrollable_frame.winfo_children():
                widget.destroy()

            selected_student = student_var.get()
            selected_grade = grade_var.get()
            start = from_date.get().strip()
            end = to_date.get().strip()

            for student in self.tracker.students.values():
                if selected_student != "All" and student.name != selected_student:
                    continue
                if selected_grade != "All" and student.grade != selected_grade:
                    continue
                for entry in student.behavior_log:
                    ts = entry["timestamp"]
                    if start and ts < start:
                        continue
                    if end and ts > end:
                        continue

                    frame_entry = ttkb.LabelFrame(scrollable_frame, text=f"{ts} – {student.name}", bootstyle="secondary")
                    frame_entry.pack(fill="x", padx=5, pady=5)

                    icon = "✅" if entry["positive"] else "⚠️"
                    class_info = f" [{entry.get('class', 'Unknown')}]"
                    desc = f"{icon} Period {entry['period']}: {entry['description']} ({entry['type']}){class_info}"
                    label = ttkb.Label(frame_entry, text=desc, foreground="white")
                    label.pack(anchor="w", padx=10)

                    # Edit & Delete Buttons
                    btn_frame = ttkb.Frame(frame_entry)
                    btn_frame.pack(anchor="e", padx=10)

                    def make_edit_callback(student_name=student.name, entry=entry):
                        return lambda: self.edit_behavior_entry(student_name, entry)

                    def make_delete_callback(student_name=student.name, entry=entry):
                        return lambda: self.delete_behavior_entry_from_log_viewer(student_name, entry, apply_filters)

                    ttkb.Button(btn_frame, text="✏️", width=3, bootstyle="warning", command=make_edit_callback()).pack(side="left", padx=2)
                    ttkb.Button(btn_frame, text="🗑️", width=3, bootstyle="danger", command=make_delete_callback()).pack(side="left", padx=2)


        # Filter button
        ttkb.Button(filters, text="Apply Filters", bootstyle="primary", command=apply_filters).grid(row=2, column=0, columnspan=4, pady=10)

        # Initial load
        apply_filters()

        # Back
        ttkb.Button(frame, text="⬅ Back", bootstyle="secondary", command=self.show_dashboard).pack(pady=10)

    def delete_behavior_entry_from_log_viewer(self, student_name, entry, refresh_callback):
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        if entry not in student.behavior_log:
            messagebox.showerror("Error", "Entry not found.")
            return

        if messagebox.askyesno("Confirm", "Are you sure you want to delete this entry?"):
            student.behavior_log.remove(entry)
            self.tracker.save_data()
            refresh_callback()
        
    def show_my_students(self):
        self.clear_main_content()
        hub_frame = ttkb.Frame(self.main_content)
        hub_frame.pack(pady=20, padx=20, fill="both", expand=True)

        ttkb.Label(hub_frame, text="My Students",
                   font=("Helvetica", 16, "bold"), foreground="white").pack(pady=10)

        students = [s for s in self.tracker.students.values() if s.pinned]
        if not students:
            ttkb.Label(hub_frame, text="No students pinned.", foreground="white").pack(pady=10)
            return

        for student in students:
            card = ttkb.LabelFrame(hub_frame, text=student.name, bootstyle="secondary")
            card.pack(fill="x", padx=10, pady=10)

            # Button Row
            btn_row = ttkb.Frame(card)
            btn_row.pack(pady=5)

            ttkb.Button(btn_row, text="📋 Student Menu", bootstyle="primary", width=18,
                        command=lambda name=student.name: self.show_student_profile(name)).pack(side="left", padx=5)

            ttkb.Button(btn_row, text="🔍 View Portfolio", bootstyle="info", width=18,
                        command=lambda name=student.name: self.show_portfolio(name)).pack(side="left", padx=5)

            ttkb.Button(btn_row, text="📌 Unpin", bootstyle="danger", width=10,
                        command=lambda name=student.name: self.unpin_and_reload(name)).pack(side="left", padx=5)

    def unpin_and_reload(self, student_name):
        student = self.tracker.students.get(student_name)
        if student:
            student.pinned = False
            self.tracker.save_data()
            self.show_my_students()

    def show_student_profile(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        # Outer frame: fills main content (dark background by default)
        outer_frame = ttkb.Frame(self.main_content)
        outer_frame.pack(fill="both", expand=True)

        # Main content is vertically padded near the top, centered horizontally (like Add Student)
        container = ttkb.Frame(outer_frame)
        container.pack(pady=36, padx=0, fill="x")  # Controls vertical spacing

        # Header/title
        ttkb.Label(container, text=f"{student.name}'s Menu",
                   font=("Helvetica", 18, "bold"),
                   foreground="#FFFFFF").pack(pady=(0, 24))

        BUTTON_WIDTH = 36

        # All buttons in a vertical column, well spaced
        ttkb.Button(container, text="Record Behavior / Add Note", width=BUTTON_WIDTH,
                    bootstyle="secondary", command=lambda: self.record_behavior(student_name)).pack(pady=5)
        ttkb.Button(container, text="Student Portfolio", width=BUTTON_WIDTH,
                    bootstyle="secondary", command=lambda: self.show_portfolio(student_name)).pack(pady=5)
        ttkb.Button(container, text="Manage Student", width=BUTTON_WIDTH,
                    bootstyle="secondary", command=lambda: self.show_manage_student(student_name)).pack(pady=5)

        # Pin/Unpin button (orange)
        pin_text = "📍 Unpin Student" if student.pinned else "📌 Pin Student"
        pin_btn = ttkb.Button(container, text=pin_text, bootstyle="warning", width=BUTTON_WIDTH,
                              command=lambda: self.toggle_pin(student_name))
        pin_btn.pack(pady=5)

        # Red "Return to Hub" button, with more vertical margin above it
        ttkb.Button(container, text="⬅ Back to Student Hub",
                    bootstyle="danger", width=BUTTON_WIDTH,
                    command=self.show_student_hub).pack(pady=(24, 0))

    def toggle_pin(self, student_name):
        student = self.tracker.students[student_name]
        student.pinned = not student.pinned
        self.tracker.save_data()
        self.show_student_profile(student_name)





    def show_manage_student(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        container = ttkb.Frame(self.main_content)
        container.place(relx=0.5, rely=0.5, anchor="center")  # Center everything

        # Title
        ttkb.Label(
            container,
            text=f"Manage {student.name}",
            font=("Helvetica", 16, "bold"),
            anchor="center",
            foreground="#ffffff"
        ).pack(pady=(0, 20), anchor="center")

        # Button configuration
        BUTTON_WIDTH = 36
        button_opts = {
            "width": BUTTON_WIDTH,
            "bootstyle": "primary",
            "padding": 6
        }

        # Buttons
        ttkb.Button(
            container,
            text="📅 Daily Schedule & Log",
            command=lambda: self.show_daily_schedule_and_log(student_name),
            **button_opts
        ).pack(pady=6)

        ttkb.Button(
            container,
            text="✏️ Edit Weekly To-Dos",
            command=lambda: self.edit_todos(student_name),
            **button_opts
        ).pack(pady=6)

        ttkb.Button(
            container,
            text="📚 Edit Classes",
            command=lambda: self.edit_classes(student_name),
            **button_opts
        ).pack(pady=6)

        ttkb.Button(
            container,
            text="📅 View Letter Day Schedule",
            command=lambda: self.show_letter_day_schedule(student_name),
            **button_opts
        ).pack(pady=6)

        ttkb.Button(
            container,
            text="📖 View / Edit Full Behavior Log",
            command=lambda: self.view_edit_full_log(student_name),
            **button_opts
        ).pack(pady=6)

        # Back button
        ttkb.Button(
            container,
            text="⬅ Back to Student Menu",
            command=lambda: self.show_student_profile(student_name),
            bootstyle="danger",
            width=BUTTON_WIDTH,
            padding=6
        ).pack(pady=(20, 10))


        
    def show_letter_day_schedule(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        frame = ttkb.Frame(self.main_content)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ttkb.Label(frame, text=f"{student.name} – Letter Day Schedule", font=("Helvetica", 16, "bold"), foreground="white").pack(pady=10)

        # Select trimester
        trimester_var = tk.StringVar(value=get_current_trimester())
        ttkb.Label(frame, text="Trimester:", foreground="white").pack(anchor="w", pady=(5,0))
        trimester_dropdown = ttkb.Combobox(frame, textvariable=trimester_var, values=list(TRIMESTERS.keys()), state="readonly")
        trimester_dropdown.pack(fill="x", pady=(0,10))

        # Select letter day
        letter_day_var = tk.StringVar(value=LETTER_DAYS[0])
        ttkb.Label(frame, text="Letter Day:", foreground="white").pack(anchor="w")
        letter_day_dropdown = ttkb.Combobox(frame, textvariable=letter_day_var, values=LETTER_DAYS, state="readonly")
        letter_day_dropdown.pack(fill="x", pady=(0,10))

        schedule_frame = ttkb.LabelFrame(frame, text="Schedule for Selected Letter Day")
        schedule_frame.pack(fill="both", expand=True, pady=15)

        def render_schedule():
            for widget in schedule_frame.winfo_children():
                widget.destroy()
            trimester = trimester_var.get()
            letter_day = letter_day_var.get()
            periods = student.classes.get(trimester, {}).get(letter_day, {})
            if not periods:
                ttkb.Label(schedule_frame, text="No schedule found for this letter day.", foreground="white").pack(anchor="w", padx=10, pady=4)
            else:
                for period in range(1, 8):
                    cls = periods.get(period, "Not Assigned")
                    ttkb.Label(schedule_frame, text=f"Period {period}: {cls}", foreground="white").pack(anchor="w", padx=10, pady=2)

        # Initial render
        render_schedule()
        trimester_dropdown.bind("<<ComboboxSelected>>", lambda e: render_schedule())
        letter_day_dropdown.bind("<<ComboboxSelected>>", lambda e: render_schedule())

        ttkb.Button(frame, text="⬅ Back to Manage Student", bootstyle="primary", command=lambda: self.show_manage_student(student_name)).pack(pady=10)

    
    def view_edit_full_log(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        frame = ttkb.Frame(self.main_content)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ttkb.Label(frame, text=f"Full Behavior Log – {student.name}", font=("Helvetica", 16, "bold"), bootstyle="inverse-light").pack(pady=10)

        # 🔍 Filters
        filter_frame = ttkb.Frame(frame)
        filter_frame.pack(pady=10, fill="x")

        ttkb.Label(filter_frame, text="From:", font=("Helvetica", 10)).pack(side="left", padx=(5, 2))
        from_var = tk.StringVar()
        ttkb.Entry(filter_frame, textvariable=from_var, width=12).pack(side="left", padx=2)

        ttkb.Label(filter_frame, text="To:", font=("Helvetica", 10)).pack(side="left", padx=(10, 2))
        to_var = tk.StringVar()
        ttkb.Entry(filter_frame, textvariable=to_var, width=12).pack(side="left", padx=2)

        ttkb.Label(filter_frame, text="Search:", font=("Helvetica", 10)).pack(side="left", padx=(10, 2))
        search_var = tk.StringVar()
        ttkb.Entry(filter_frame, textvariable=search_var, width=20).pack(side="left", padx=2)

        # Export button
        def export_logs():
            from tkinter import filedialog
            import csv
            file = filedialog.asksaveasfilename(defaultextension=".csv")
            if file:
                with open(file, "w", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow(["Date", "Period", "Class", "Type", "Positive", "Description"])
                    for log in filtered_logs:
                        writer.writerow([
                            log["timestamp"],
                            log["period"],
                            log.get("class", "Unknown"),
                            log["type"],
                            "Yes" if log["positive"] else "No",
                            log["description"]
                        ])
                messagebox.showinfo("Exported", "Logs exported successfully.")

        ttkb.Button(filter_frame, text="Export to CSV", command=export_logs, bootstyle="secondary").pack(side="right", padx=10)

        # 📜 Log area
        canvas = tk.Canvas(frame, highlightthickness=0)
        scrollbar = ttkb.Scrollbar(frame, orient="vertical", command=canvas.yview)
        log_container = ttkb.Frame(canvas)

        canvas.create_window((0, 0), window=log_container, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        log_container.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        def refresh_log():
            for widget in log_container.winfo_children():
                widget.destroy()

            nonlocal filtered_logs
            filtered_logs = []

            from_date = from_var.get().strip()
            to_date = to_var.get().strip()
            keyword = search_var.get().lower().strip()

            for i, entry in enumerate(student.behavior_log):
                if from_date and entry["timestamp"] < from_date:
                    continue
                if to_date and entry["timestamp"] > to_date:
                    continue
                if keyword and (keyword not in entry["type"].lower() and keyword not in entry["description"].lower()):
                    continue

                filtered_logs.append(entry)

                entry_frame = ttkb.LabelFrame(log_container, text=f"{entry['timestamp']} - Period {entry['period']}", bootstyle="secondary")
                entry_frame.pack(fill="x", padx=5, pady=5)

                icon = "✅" if entry["positive"] else "⚠️"
                class_info = f" [{entry.get('class', 'Unknown')}]"
                desc = f"{icon} {entry['description']} ({entry['type']}){class_info}"

                ttkb.Label(entry_frame, text=desc, bootstyle="inverse-light").pack(side="left", padx=10, pady=5)

                def make_edit_func(index):
                    return lambda: self.edit_log_entry(student_name, index)

                def make_delete_func(index):
                    return lambda: self.delete_log_entry(student_name, index)

                btns = ttkb.Frame(entry_frame)
                btns.pack(side="right")
                ttkb.Button(btns, text="Edit", width=8, bootstyle="warning", command=make_edit_func(i)).pack(side="left", padx=5)
                ttkb.Button(btns, text="Delete", width=8, bootstyle="danger", command=make_delete_func(i)).pack(side="left")

        # Initialize empty
        filtered_logs = []
        refresh_log()

        # Auto-refresh on typing
        for var in [from_var, to_var, search_var]:
            var.trace_add("write", lambda *_: refresh_log())

        ttkb.Button(frame, text="⬅ Back", bootstyle="primary", command=lambda: self.show_manage_student(student_name)).pack(pady=10)


    def edit_log_entry(self, student_name, index):
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        entry = student.behavior_log[index]
        edit_win = tk.Toplevel(self.root)
        edit_win.title("Edit Log Entry")
        edit_win.geometry("400x300")
        

        ttkb.Label(edit_win, text="Description:").pack(anchor="w", padx=10)
        desc_entry = tk.Text(edit_win, height=4)
        desc_entry.insert("1.0", entry["description"])
        desc_entry.pack(fill="x", padx=10)

        type_var = tk.StringVar(value=entry["type"])
        ttkb.Label(edit_win, text="Type:").pack(anchor="w", padx=10, pady=(10, 0))
        ttkb.Combobox(edit_win, textvariable=type_var, values=["Disruption", "On Task", "Participation", "Defiance", "Respect", "Helpfulness"], state="readonly").pack(fill="x", padx=10)

        is_pos_var = tk.BooleanVar(value=entry["positive"])
        ttkb.Checkbutton(edit_win, text="Positive?", variable=is_pos_var).pack(anchor="w", padx=10, pady=5)

        def save():
            entry["description"] = desc_entry.get("1.0", tk.END).strip()
            entry["type"] = type_var.get()
            entry["positive"] = is_pos_var.get()
            self.tracker.save_data()
            edit_win.destroy()
            self.view_edit_full_log(student_name)

        ttkb.Button(edit_win, text="Save", bootstyle="success", command=save).pack(pady=10)

    def delete_log_entry(self, student_name, index):
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        if messagebox.askyesno("Confirm", "Delete this log entry?"):
            del student.behavior_log[index]
            self.tracker.save_data()
            self.view_edit_full_log(student_name)

        
    def record_behavior(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        form_frame = ttkb.Frame(self.main_content)
        form_frame.pack(padx=20, pady=20, fill="both", expand=True)

        # --- Letter Day Dropdown ---
        letter_day_var = tk.StringVar(value=get_current_letter_day())
        ttkb.Label(form_frame, text="Letter Day:", foreground="#FFFFFF").pack(anchor="w")
        ttkb.Combobox(form_frame, textvariable=letter_day_var, values=LETTER_DAYS, state="readonly").pack(fill="x", pady=5)


        ttkb.Label(form_frame, text=f"Record Behavior - {student.name}",
                   foreground="#FFFFFF", font=("Helvetica", 16, "bold")).pack(pady=10)

        ttkb.Label(form_frame, text="Date (YYYY-MM-DD):", foreground="#FFFFFF").pack(anchor="w", pady=(10, 0))
        date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        ttkb.Entry(form_frame, textvariable=date_var).pack(fill="x", pady=5)

        ttkb.Label(form_frame, text="Behavior Type:", foreground="#FFFFFF").pack(anchor="w")
        behavior_type_var = tk.StringVar()
        ttkb.Combobox(form_frame, textvariable=behavior_type_var,
                      values=["Disruption", "On Task", "Participation", "Defiance", "Respect", "Helpfulness"],
                      state="readonly").pack(fill="x", pady=5)

        ttkb.Label(form_frame, text="Was it Positive?", foreground="#FFFFFF").pack(anchor="w", pady=(10, 0))
        is_positive_var = tk.IntVar()
        radio_frame = ttkb.Frame(form_frame); radio_frame.pack(anchor="w", pady=5)
        ttkb.Radiobutton(radio_frame, text="✅ Yes", variable=is_positive_var, value=1, bootstyle="success").pack(side="left", padx=10)
        ttkb.Radiobutton(radio_frame, text="⚠️ No", variable=is_positive_var, value=0, bootstyle="danger").pack(side="left", padx=10)

        ttkb.Label(form_frame, text="Class Period (1–7):", foreground="#FFFFFF").pack(anchor="w", pady=(10, 0))
        period_var = tk.IntVar()
        period_frame = ttkb.Frame(form_frame); period_frame.pack(anchor="w", pady=5)
        for i in range(1, 8):
            ttkb.Radiobutton(period_frame, text=str(i), variable=period_var, value=i, bootstyle="info").pack(side="left", padx=4)

        ttkb.Label(form_frame, text="Behavior Description:", foreground="#FFFFFF").pack(anchor="w", pady=(10, 0))
        description_entry = tk.Text(form_frame, height=4)
        description_entry.pack(fill="both", pady=5)

        def submit():
            behavior_type = behavior_type_var.get()
            is_positive = bool(is_positive_var.get())
            period = period_var.get()
            description = description_entry.get("1.0", tk.END).strip()
            date_str = date_var.get()

            if not behavior_type or period not in range(1, 8) or not description or not date_str:
                messagebox.showerror("Error", "Please complete all fields.")
                return

            current_trimester = get_current_trimester()
            selected_letter_day = letter_day_var.get()
            class_subject = student.classes.get(current_trimester, {}).get(selected_letter_day, {}).get(period, "Unknown")

            self.tracker.record_behavior(
                student_name, description, behavior_type, is_positive, period, class_subject, selected_letter_day, date_str
            )

            messagebox.showinfo("Success", "Behavior recorded.")
            self.show_manage_student(student_name)

        ttkb.Button(form_frame, text="Save Behavior and Return",
                    bootstyle="primary", width=30, command=submit).pack(pady=15)

        ttkb.Button(form_frame, text="⬅ Back to Menu", bootstyle="secondary",
                command=lambda: self.show_student_profile(student_name)).pack(pady=10)

    def summarize_by_date(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        frame = ttkb.Frame(self.main_content)
        frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttkb.Label(frame, text=f"Summarize Behavior by Date – {student.name}",
                   font=("Helvetica", 16, "bold"), foreground="white").pack(pady=10)

        ttkb.Label(frame, text="Enter Date (YYYY-MM-DD):", font=("Helvetica", 12), bootstyle="secondary").pack(pady=5)
        date_var = tk.StringVar()
        date_entry = ttkb.Entry(frame, textvariable=date_var)
        date_entry.pack(pady=5)

        result_label = ttkb.Label(frame, text="", font=("Helvetica", 12), bootstyle="secondary")
        result_label.pack(pady=10)

        def summarize():
            date = date_var.get().strip()
            result = self.tracker.summarize_student_behavior_by_date(student_name, date)
            if result:
                result_label.config(
                    text=f"✅ Positive: {result['positive']}   ⚠️ Negative: {result['negative']}"
                )
            else:
                result_label.config(text="No data found for that date.")

        ttkb.Button(frame, text="Summarize", command=summarize, bootstyle="primary").pack(pady=5)
        ttkb.Button(frame, text="⬅ Back to Menu", command=lambda: self.show_student_profile(student_name), bootstyle="secondary").pack(pady=10)

    def show_daily_schedule_and_log(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        today = datetime.now().strftime("%Y-%m-%d")
        current_trimester = get_current_trimester()
        letter_day = get_current_letter_day()

        main_frame = ttkb.Frame(self.main_content)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        header = ttkb.Label(
            main_frame,
            text=f"{student.name} – Daily Schedule & Log",
            font=("Helvetica", 16, "bold"),
            foreground="white"
        )
        header.pack(anchor="center", pady=10)

        page_var = tk.StringVar(value="today")  # "today" or "letter_day"

        # Toggle buttons
        btn_row = ttkb.Frame(main_frame)
        btn_row.pack(anchor="center", pady=(0, 10))
        btn_today = ttkb.Button(btn_row, text="Today’s Schedule & Log", bootstyle="info", command=lambda: page_var.set("today"))
        btn_today.pack(side="left", padx=10)
        btn_table = ttkb.Button(btn_row, text="Letter Day Schedule Table", bootstyle="secondary", command=lambda: page_var.set("letter_day"))
        btn_table.pack(side="left", padx=10)

        content_frame = ttkb.Frame(main_frame)
        content_frame.pack(fill="both", expand=True)
        content_frame.columnconfigure(0, weight=1)
        content_frame.rowconfigure(0, weight=1)
        content_frame.rowconfigure(1, weight=1)

        def render_page(*_):
            if page_var.get() == "today":
                btn_today.config(bootstyle="info")
                btn_table.config(bootstyle="secondary")
            else:
                btn_today.config(bootstyle="secondary")
                btn_table.config(bootstyle="info")

            for widget in content_frame.winfo_children():
                widget.destroy()

            if page_var.get() == "today":
                # Schedule + Log view
                content_frame.columnconfigure(0, weight=1)
                content_frame.columnconfigure(1, weight=1)

                schedule_frame = ttkb.LabelFrame(content_frame, text="Today's Schedule")
                schedule_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10), pady=5)
                schedule = student.classes.get(current_trimester, {}).get(letter_day, {})
                for period in range(1, 8):
                    cls = schedule.get(period, "Not Assigned")
                    ttkb.Label(schedule_frame, text=f"Period {period}: {cls}", foreground="white").pack(anchor="w", pady=4)

                log_frame_container = ttkb.Frame(content_frame)
                log_frame_container.grid(row=0, column=1, sticky="nsew", padx=(10, 0), pady=5)
                log_frame_container.rowconfigure(0, weight=1)
                log_frame_container.columnconfigure(0, weight=1)

                canvas = tk.Canvas(log_frame_container, bg="#1E1E1E", highlightthickness=0)
                scrollbar = ttkb.Scrollbar(log_frame_container, orient="vertical", command=canvas.yview)
                scrollable_log = ttkb.Frame(canvas)

                scrollable_log.bind(
                    "<Configure>",
                    lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
                )
                canvas.create_window((0, 0), window=scrollable_log, anchor="nw")
                canvas.configure(yscrollcommand=scrollbar.set)

                canvas.grid(row=0, column=0, sticky="nsew")
                scrollbar.grid(row=0, column=1, sticky="ns")

                for period in range(1, 8):
                    ttkb.Label(
                        scrollable_log,
                        text=f"Period {period} Log",
                        font=("Helvetica", 12, "bold"),
                        foreground="white"
                    ).pack(anchor="w", pady=(8, 2))
                    logs = [
                        entry for entry in student.behavior_log
                        if entry.get("timestamp") == today and entry.get("period") == period
                    ]
                    if logs:
                        for log in logs:
                            icon = "✅" if log["positive"] else "⚠️"
                            class_info = f" [{log.get('class', 'Unknown')}]"
                            log_text = f"{icon} {log['description']} ({log['type']}){class_info}"
                            ttkb.Label(scrollable_log, text=log_text, foreground="white").pack(anchor="w", padx=10, pady=2)
                    else:
                        ttkb.Label(scrollable_log, text="– No records –", foreground="#AAAAAA").pack(anchor="w", padx=10, pady=2)
            else:
                # Letter Day Schedule Table
                ttkb.Label(
                    content_frame,
                    text=f"Letter Day Schedule Table (Trimester: {current_trimester})",
                    font=("Helvetica", 14, "bold"),
                    foreground="white"
                ).grid(row=0, column=0, pady=(0, 10), sticky="n")

                table = ttkb.Frame(content_frame)
                table.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
                content_frame.rowconfigure(1, weight=1)
                content_frame.columnconfigure(0, weight=1)

                ttkb.Label(table, text="Period", width=10, bootstyle="secondary").grid(row=0, column=0, padx=2, pady=2, sticky="nsew")
                for col, ld in enumerate(LETTER_DAYS):
                    ttkb.Label(table, text=ld, width=12, bootstyle="secondary").grid(row=0, column=col+1, padx=2, pady=2, sticky="nsew")

                for row in range(1, 8):
                    ttkb.Label(table, text=f"Period {row}", width=10, bootstyle="secondary").grid(row=row, column=0, padx=2, pady=2, sticky="nsew")
                    for col, ld in enumerate(LETTER_DAYS):
                        class_name = student.classes.get(current_trimester, {}).get(ld, {}).get(row, "—")
                        ttkb.Label(table, text=class_name, width=12, bootstyle="light").grid(row=row, column=col+1, padx=2, pady=2, sticky="nsew")

                # Let each column in the table expand equally
                for col in range(len(LETTER_DAYS) + 1):
                    table.columnconfigure(col, weight=1)
                for row in range(1, 8):
                    table.rowconfigure(row, weight=1)

        page_var.trace_add("write", render_page)
        render_page()

        ttkb.Button(
            main_frame,
            text="⬅ Back to Manage Student",
            bootstyle="primary",
            command=lambda: self.show_manage_student(student_name)
        ).pack(pady=15)
    
    def show_full_log(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        frame = ttkb.Frame(self.main_content, bootstyle="secondary")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ttkb.Label(frame, text=f"{student.name} - Full Behavior Log", font=("Helvetica", 16, "bold"),
                   bootstyle="inverse-light").pack(pady=10)

        log_container = tk.Canvas(frame, highlightthickness=0)
        scrollbar = ttkb.Scrollbar(frame, orient="vertical", command=log_container.yview)
        scrollable_frame = ttkb.Frame(log_container, bootstyle="secondary")

        log_container.create_window((0, 0), window=scrollable_frame, anchor="nw")
        log_container.configure(yscrollcommand=scrollbar.set)

        log_container.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        scrollable_frame.bind("<Configure>", lambda e: log_container.configure(scrollregion=log_container.bbox("all")))

        grouped_logs = {}
        for log in student.behavior_log:
            date = log["timestamp"]
            grouped_logs.setdefault(date, []).append(log)

        for date in sorted(grouped_logs.keys(), reverse=True):
            ttkb.Label(scrollable_frame, text=f"📅 {date}", bootstyle="inverse-light").pack(anchor="w", padx=5, pady=(10, 5))
            for i, log in enumerate(grouped_logs[date]):
                frame_row = ttkb.Frame(scrollable_frame, bootstyle="secondary")
                frame_row.pack(fill="x", padx=15, pady=3)

                icon = "✅" if log["positive"] else "⚠️"
                display_text = f"{icon} [{log['type']}] (Period {log['period']}): {log['description']}"

                ttkb.Label(frame_row, text=display_text, bootstyle="secondary").pack(side="left", fill="x", expand=True)

                def make_edit_callback(log_ref=log):
                    return lambda: self.edit_behavior_entry(student_name, log_ref)

                def make_delete_callback(index=i, date_key=date):
                    return lambda: self.delete_behavior_entry(student_name, date_key, index)

                ttkb.Button(frame_row, text="✏️", width=3, command=make_edit_callback()).pack(side="right", padx=2)
                ttkb.Button(frame_row, text="🗑️", width=3, bootstyle="danger-outline", command=make_delete_callback()).pack(side="right")

        ttkb.Button(frame, text="⬅ Back to Menu", bootstyle="secondary", command=lambda: self.show_student_profile(student_name)).pack(pady=15)


 
    def show_portfolio(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        today = datetime.now().strftime("%Y-%m-%d")

        # === SCROLLABLE CONTAINER FRAME ===
        container = ttkb.Frame(self.main_content)
        container.grid(row=0, column=0, sticky="nsew")  # ✅ Fill entire main_content
        self.main_content.rowconfigure(0, weight=1)
        self.main_content.columnconfigure(0, weight=1)

        # === CANVAS FOR SCROLLING ===
        canvas = tk.Canvas(container, bg="#121212", highlightthickness=0)
        canvas.grid(row=0, column=0, sticky="nsew")  # ✅ Expand canvas horizontally and vertically
        
        def resize_scroll_region(event):
            canvas.itemconfig("all", width=event.width)

        canvas.bind("<Configure>", resize_scroll_region)


        # === SCROLLBAR ===
        scrollbar = ttkb.Scrollbar(container, orient="vertical", command=canvas.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")

        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)

        # === FRAME INSIDE CANVAS ===
        scrollable_frame = ttkb.Frame(canvas)
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw", width=canvas.winfo_width())


        # ✅ This ensures horizontal responsiveness
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all"), width=e.width))

        # ✅ Ensure scrollable_frame widgets expand with width
        scrollable_frame.columnconfigure(0, weight=1)
        scrollable_frame.columnconfigure(1, weight=1)  # If you're using 2-column layout

        # ========== Variables ==========
        edit_mode = tk.BooleanVar(value=False)
        age_var = tk.StringVar(value=student.age or "")
        dob_var = tk.StringVar(value=getattr(student, "dob", ""))
        program_var = tk.StringVar(value=student.program or "")
        summary_var = tk.StringVar(value=student.summary or "")
        todo_var = tk.StringVar()

        # ========== Top Info & Image ==========
        top_frame = ttkb.Frame(scrollable_frame)
        top_frame.grid(row=0, column=0, columnspan=2, sticky="ew", padx=20, pady=(15, 5))
        top_frame.columnconfigure(0, weight=3)
        top_frame.columnconfigure(1, weight=1)

        # --- Info
        info_frame = ttkb.LabelFrame(top_frame, text="Basic Info")
        info_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        def labeled_entry(parent, label, var):
            row = ttkb.Frame(parent)
            row.pack(fill="x", pady=4)
            ttkb.Label(row, text=label, width=12, anchor="w").pack(side="left")
            entry = ttkb.Entry(row, textvariable=var, state="disabled")
            entry.pack(side="left", fill="x", expand=True)
            return entry

        age_entry = labeled_entry(info_frame, "Age:", age_var)
        program_entry = labeled_entry(info_frame, "Program:", program_var)
        dob_entry = labeled_entry(info_frame, "Date of Birth:", dob_var)

        # --- Image
        image_frame = ttkb.Frame(top_frame)
        image_frame.grid(row=0, column=1, sticky="ne")
        ttkb.Label(image_frame, text=student.name, font=("Segoe UI", 12)).pack(pady=(0, 5))
        profile_img_label = ttkb.Label(image_frame)
        profile_img_label.pack()

        def load_profile_image(path):
            try:
                img = Image.open(path or "profile.png").resize((100, 100))
                photo = ImageTk.PhotoImage(img)
                profile_img_label.config(image=photo)
                profile_img_label.image = photo
            except:
                profile_img_label.config(text="No Image")

        load_profile_image(student.image_path)

        def upload_new_image():
            path = filedialog.askopenfilename(filetypes=[("Image files", "*.png *.jpg *.jpeg")])
            if path:
                student.image_path = path
                load_profile_image(path)

        ttkb.Button(image_frame, text="Upload Image", command=upload_new_image).pack(pady=5)

        # ========== Summary ==========
        summary_frame = ttkb.LabelFrame(scrollable_frame, text="Student Summary")
        summary_frame.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=20, pady=10)
        summary_entry = tk.Text(summary_frame, height=3, state="disabled")
        summary_entry.insert("1.0", student.summary)
        summary_entry.pack(fill="both", padx=5, pady=5)

        # ========== IEP + To-Dos ==========
        goals_frame = ttkb.LabelFrame(scrollable_frame, text="IEP Goals / Behavior Plans")
        goals_frame.grid(row=2, column=0, sticky="nsew", padx=(20, 10), pady=10)
        goals_entry = tk.Text(goals_frame, height=6, state="disabled")
        goals_entry.insert("1.0", student.goals or "")
        goals_entry.pack(fill="both", padx=5, pady=5)

        todos_frame = ttkb.LabelFrame(scrollable_frame, text="Weekly To-Dos")
        todos_frame.grid(row=2, column=1, sticky="nsew", padx=(10, 20), pady=10)
        todos_listbox = tk.Listbox(todos_frame, height=6)
        for todo in student.weekly_todos:
            todos_listbox.insert(tk.END, todo)
        todos_listbox.pack(fill="both", padx=5, pady=5)

        todo_entry = ttkb.Entry(todos_frame, textvariable=todo_var)
        todo_entry.pack(fill="x", padx=5, pady=(0, 5))

        def add_task():
            task = todo_var.get().strip()
            if task:
                todos_listbox.insert(tk.END, task)
                todo_var.set("")

        def remove_task():
            sel = todos_listbox.curselection()
            if sel:
                todos_listbox.delete(sel[0])

        todo_btns = ttkb.Frame(todos_frame)
        todo_btns.pack(pady=5)
        ttkb.Button(todo_btns, text="Add", command=add_task).pack(side="left", padx=5)
        ttkb.Button(todo_btns, text="Remove", command=remove_task).pack(side="right", padx=5)

        # ========== Trimester + Letter Day ==========
        current_trimester = tk.StringVar(value=get_current_trimester())
        selected_letter_day = tk.StringVar(value=LETTER_DAYS[0])

        control_frame = ttkb.Frame(scrollable_frame)
        control_frame.grid(row=3, column=0, columnspan=2, sticky="ew", padx=20)

        ttkb.Label(control_frame, text="Trimester:").grid(row=0, column=0, padx=10)
        ttkb.Combobox(control_frame, textvariable=current_trimester, values=list(TRIMESTERS.keys()), state="readonly").grid(row=0, column=1)

        ttkb.Label(control_frame, text="Letter Day:").grid(row=0, column=2, padx=10)
        ttkb.Combobox(control_frame, textvariable=selected_letter_day, values=LETTER_DAYS, state="readonly").grid(row=0, column=3)

        # ========== Classes ==========
        classes_frame = ttkb.LabelFrame(scrollable_frame, text="Classes")
        classes_frame.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=20, pady=10)

        def render_classes():
            for widget in classes_frame.winfo_children():
                widget.destroy()
            trimester = current_trimester.get()
            schedule = student.classes.get(trimester, {})
            class_set = set()
            for day in LETTER_DAYS:
                class_set.update(schedule.get(day, {}).values())
            if not class_set:
                ttkb.Label(classes_frame, text="No classes assigned.").pack()
            else:
                for cls in sorted(class_set):
                    ttkb.Label(classes_frame, text=cls).pack(anchor="w", padx=10, pady=2)

        render_classes()
        current_trimester.trace_add("write", lambda *_: render_classes())

        # ========== Today's Log ==========
        log_frame = ttkb.LabelFrame(scrollable_frame, text=f"Today's Log – {today}")
        log_frame.grid(row=5, column=0, columnspan=2, sticky="nsew", padx=20, pady=(0, 10))

        period_logs = {i: [] for i in range(1, 8)}
        for entry in student.behavior_log:
            if entry["timestamp"] == today:
                period_logs[entry["period"]].append(entry)

        for i in range(1, 8):
            ttkb.Label(log_frame, text=f"Period {i}:").pack(anchor="w", padx=5)
            logs = period_logs[i]
            if logs:
                for log in logs:
                    icon = "✅" if log["positive"] else "⚠️"
                    ttkb.Label(log_frame, text=f"  {icon} {log['description']} ({log['type']})").pack(anchor="w", padx=10)
            else:
                ttkb.Label(log_frame, text="  – No records").pack(anchor="w", padx=10)

        # ========== Button Row ==========
        def toggle_edit():
            state = "normal" if not edit_mode.get() else "disabled"
            edit_mode.set(not edit_mode.get())
            for entry in [age_entry, program_entry, dob_entry]:
                entry.config(state=state)
            summary_entry.config(state=state)
            goals_entry.config(state=state)
            todo_entry.config(state=state)

        def save_profile():
            if not edit_mode.get():
                messagebox.showinfo("Edit Mode", "Enable Edit Mode first.")
                return
            student.age = age_var.get()
            student.dob = dob_var.get()
            student.program = program_var.get()
            student.summary = summary_entry.get("1.0", tk.END).strip()
            student.goals = goals_entry.get("1.0", tk.END).strip()
            student.weekly_todos = todos_listbox.get(0, tk.END)
            self.tracker.save_data()
            messagebox.showinfo("Saved", "Student profile updated.")

        def delete_student():
            if messagebox.askyesno("Confirm", f"Delete {student.name}?"):
                del self.tracker.students[student.name]
                self.tracker.save_data()
                self.show_student_hub()

        def export_trimester_summary():
            logs = [
                entry for entry in student.behavior_log
                if entry.get("letter_day") == selected_letter_day.get()
                and get_current_trimester() == current_trimester.get()
            ]
            if not logs:
                messagebox.showinfo("No Data", "No logs found.")
                return
            path = filedialog.asksaveasfilename(defaultextension=".csv")
            if path:
                import csv
                with open(path, "w", newline="") as f:
                    writer = csv.DictWriter(f, fieldnames=[
                        "Date", "Letter Day", "Period", "Type", "Positive", "Description", "Class"
                    ])
                    writer.writeheader()
                    for log in logs:
                        writer.writerow({
                            "Date": log["timestamp"],
                            "Letter Day": log.get("letter_day", ""),
                            "Period": log["period"],
                            "Type": log["type"],
                            "Positive": "Yes" if log["positive"] else "No",
                            "Description": log["description"],
                            "Class": log.get("class", "")
                        })
                messagebox.showinfo("Exported", "Trimester summary exported.")

        button_frame = ttkb.Frame(scrollable_frame)
        button_frame.grid(row=6, column=0, columnspan=2, pady=20)
        ttkb.Button(button_frame, text="✏️ Edit", command=toggle_edit).grid(row=0, column=0, padx=10)
        ttkb.Button(button_frame, text="💾 Save", command=save_profile).grid(row=0, column=1, padx=10)
        ttkb.Button(button_frame, text="🗑️ Delete", command=delete_student).grid(row=0, column=2, padx=10)
        ttkb.Button(button_frame, text="⬅ Back", command=self.show_student_hub).grid(row=0, column=3, padx=10)
        ttkb.Button(button_frame, text="📤 Export Summary", command=export_trimester_summary).grid(row=0, column=4, padx=10)



    def show_restore_deleted(self):
        self.clear_main_content()
        frame = ttkb.Frame(self.main_content, bootstyle="secondary")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ttkb.Label(frame, text="🧾 Restore Deleted Students", bootstyle="inverse-light").pack(pady=10)

        try:
            with open("deleted_students_log.json", "r") as f:
                deleted_log = json.load(f)
        except FileNotFoundError:
            deleted_log = []

        if not deleted_log:
            # Line needing correction: replace fg/bg with bootstyle
            ttkb.Label(frame, text="No deleted students found.", bootstyle="muted").pack(pady=20)
            return

        listbox = tk.Listbox(frame)
        for entry in deleted_log:
            listbox.insert(tk.END, f"{entry['name']} - Grade {entry['grade']} (Deleted {entry['deleted_on']})")
        listbox.pack(fill="both", expand=True, pady=10)

        def restore_selected():
            index = listbox.curselection()
            if not index:
                messagebox.showerror("Error", "Please select a student to restore.")
                return
            student_data = deleted_log[index[0]]
            if messagebox.askyesno("Confirm Restore", f"Restore {student_data['name']} to the system?"):
                restored = Student(
                    student_data["name"], student_data["grade"], student_data.get("age"),
                    student_data.get("goals"), student_data.get("program"), None,
                    student_data.get("summary")
                )
                restored.classes = student_data.get("classes", {})
                restored.weekly_todos = student_data.get("weekly_todos", [])
                restored.behavior_log = student_data.get("behavior_log", [])
                restored.dob = student_data.get("dob", "")
                self.tracker.students[restored.name] = restored
                deleted_log.pop(index[0])
                with open("deleted_students_log.json", "w") as f:
                    json.dump(deleted_log, f, indent=4)
                self.tracker.save_data()
                messagebox.showinfo("Restored", f"{restored.name} has been restored.")
                self.show_student_hub()

        # Buttons: replace bg/fg with bootstyle
        ttkb.Button(frame, text="🔁 Restore Selected", bootstyle="primary", command=restore_selected).pack(pady=10)
        ttkb.Button(frame, text="⬅ Back", bootstyle="secondary", command=self.show_settings).pack(pady=5)

    
    def show_reports(self):
        self.clear_main_content()
        reports_frame = ttkb.Frame(self.main_content)
        reports_frame.pack(pady=20, padx=20, fill="both", expand=True)

        ttkb.Label(reports_frame, text="📊 Reports Center", font=("Helvetica", 16, "bold")).pack(pady=10)

        filter_frame = ttkb.LabelFrame(reports_frame, text="Filter Options")
        filter_frame.pack(fill="x", pady=10)

        ttkb.Label(filter_frame, text="Start Date (YYYY-MM-DD):").grid(row=0, column=0, padx=5, pady=5)
        start_date = ttkb.Entry(filter_frame)
        start_date.grid(row=0, column=1, padx=5, pady=5)

        ttkb.Label(filter_frame, text="End Date (YYYY-MM-DD):").grid(row=0, column=2, padx=5, pady=5)
        end_date = ttkb.Entry(filter_frame)
        end_date.grid(row=0, column=3, padx=5, pady=5)

        ttkb.Label(filter_frame, text="Grade:").grid(row=1, column=0, padx=5, pady=5)
        grade_filter = ttkb.Combobox(filter_frame, values=["All", "5th", "6th", "7th", "8th"], state="readonly")
        grade_filter.set("All")
        grade_filter.grid(row=1, column=1, padx=5, pady=5)

        ttkb.Label(filter_frame, text="Program:").grid(row=1, column=2, padx=5, pady=5)
        program_filter = ttkb.Combobox(filter_frame, values=["All", "Compass", "Access"], state="readonly")
        program_filter.set("All")
        program_filter.grid(row=1, column=3, padx=5, pady=5)

        LETTER_DAYS = ["A", "B", "C", "D", "E", "T"]

        ttkb.Label(filter_frame, text="Letter Day:").grid(row=1, column=4, padx=5, pady=5)
        letter_day_filter = ttkb.Combobox(filter_frame, values=["All"] + LETTER_DAYS, state="readonly")
        letter_day_filter.set("All")
        letter_day_filter.grid(row=1, column=5, padx=5, pady=5)


        result_area = tk.Text(reports_frame, height=20, bg="#1E1E1E", fg="white", wrap="word")
        result_area.pack(fill="both", expand=True, pady=10)
        result_area.config(state="disabled")

        def run_report():
            result_area.config(state="normal")
            result_area.delete("1.0", tk.END)
            s_date = start_date.get()
            e_date = end_date.get()
            g_filter = grade_filter.get()
            p_filter = program_filter.get()

            all_logs = []
            for student in self.tracker.students.values():
                if g_filter != "All" and student.grade != g_filter:
                    continue
                if p_filter != "All" and student.program != p_filter:
                    continue
                for log in student.behavior_log:
                    if s_date and log["timestamp"] < s_date:
                        continue
                    if e_date and log["timestamp"] > e_date:
                        continue
                    all_logs.append((student.name, log))

            result_area.insert(tk.END, f"🧾 Total Entries: {len(all_logs)}\n\n")
            for name, log in all_logs:
                icon = "✅" if log["positive"] else "⚠️"
                result_area.insert(tk.END, f"{log['timestamp']} – {name} – Period {log['period']} – {icon} {log['description']} ({log['type']})\n")

            result_area.config(state="disabled")

            filtered_logs = [
                {
                    "Name": name,
                    "Positive": "Yes" if log["positive"] else "No"
                }
                for name, log in all_logs
            ]
            display_student_summary(filtered_logs)

        def export_to_csv():
            import csv
            file_path = filedialog.asksaveasfilename(defaultextension=".csv",
                                                     filetypes=[("CSV Files", "*.csv")],
                                                     title="Save Report As")
            if not file_path:
                return

            s_date = start_date.get()
            e_date = end_date.get()
            g_filter = grade_filter.get()
            p_filter = program_filter.get()
            selected_letter_day = letter_day_filter.get()

            selected_letter_day = letter_day_filter.get()

            all_logs = []
            for student in self.tracker.students.values():
                if g_filter != "All" and student.grade != g_filter:
                    continue
                if p_filter != "All" and student.program != p_filter:
                    continue
                for log in student.behavior_log:
                    if s_date and log["timestamp"] < s_date:
                        continue
                    if e_date and log["timestamp"] > e_date:
                        continue
                    if selected_letter_day != "All" and log.get("letter_day", "A") != selected_letter_day:
                        continue
                    all_logs.append({
                        "Name": student.name,
                        "Grade": student.grade,
                        "Program": student.program or "",
                        "Date": log["timestamp"],
                        "Letter Day": log.get("letter_day", "A"),  # <-- new column
                        "Period": log["period"],
                        "Type": log["type"],
                        "Description": log["description"],
                        "Positive": "Yes" if log["positive"] else "No",
                        "Class": log.get("class", "Unknown")
                    })

            if not all_logs:
                messagebox.showinfo("No Data", "No logs found matching the selected filters.")
                return

            try:
                with open(file_path, "w", newline="") as f:
                    writer = csv.DictWriter(f, fieldnames=list(all_logs[0].keys()))
                    writer.writeheader()
                    writer.writerows(all_logs)
                messagebox.showinfo("Success", f"Report exported to {file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export CSV: {str(e)}")


            def display_student_summary(filtered_logs):
                summary_frame = ttkb.Frame(reports_frame)
                summary_frame.pack(pady=10, fill="x")

                title = ttkb.Label(summary_frame, text="Student Behavior Summary", font=("Helvetica", 14, "bold"))
                title.pack(pady=(5, 10))

                summary = {}
                for entry in filtered_logs:
                    name = entry["Name"]
                    if name not in summary:
                        summary[name] = {"positive": 0, "negative": 0}
                    if entry["Positive"] == "Yes":
                        summary[name]["positive"] += 1
                    else:
                        summary[name]["negative"] += 1

                for student, counts in summary.items():
                    text = f"{student} — ✅ {counts['positive']}  ⚠️ {counts['negative']}"
                    ttkb.Label(summary_frame, text=text, font=("Helvetica", 12)).pack(anchor="w", padx=10)

        ttkb.Button(reports_frame, text="Generate Report", bootstyle="success", command=run_report).pack(pady=5)
        ttkb.Button(reports_frame, text="📤 Export to CSV", bootstyle="primary", command=lambda: export_to_csv()).pack(pady=5)

    def edit_letter_day_schedule(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        edit_frame = ttkb.Frame(self.main_content)
        edit_frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttkb.Label(edit_frame, text=f"Edit Letter Day Schedule – {student.name}",
                   font=("Helvetica", 16, "bold"), foreground="white").pack(pady=10)

        trimester_var = tk.StringVar(value=get_current_trimester())
        ttkb.Label(edit_frame, text="Select Trimester:", foreground="white").pack(anchor="w")
        trimester_dropdown = ttkb.Combobox(
            edit_frame, textvariable=trimester_var,
            values=list(TRIMESTERS.keys()), state="readonly"
        )
        trimester_dropdown.pack(fill="x", pady=5)

        fields = {}  # (letter_day, period): tk.StringVar

        table = ttkb.Frame(edit_frame)
        table.pack(fill="both", expand=True, pady=10)

        # Header row
        ttkb.Label(table, text="Period", width=10, bootstyle="secondary").grid(row=0, column=0, padx=2, pady=2)
        for col, letter_day in enumerate(LETTER_DAYS):
            ttkb.Label(table, text=letter_day, width=12, bootstyle="secondary").grid(row=0, column=col+1, padx=2, pady=2)

        def load_schedule(*_):
            for row in range(1, 8):
                ttkb.Label(table, text=f"Period {row}", width=10, bootstyle="secondary").grid(row=row, column=0, padx=2, pady=2)
                for col, letter_day in enumerate(LETTER_DAYS):
                    var = tk.StringVar()
                    var.set(student.get_class_for(trimester_var.get(), letter_day, row))
                    entry = ttkb.Entry(table, textvariable=var, width=12)
                    entry.grid(row=row, column=col+1, padx=2, pady=2)
                    fields[(letter_day, row)] = var

        trimester_var.trace_add("write", lambda *_: load_schedule())
        load_schedule()

        def save_schedule():
            trimester = trimester_var.get()
            for (letter_day, period), var in fields.items():
                val = var.get().strip()
                default_val = DEFAULT_SCHEDULES.get(student.grade, {}).get(trimester, {}).get(letter_day, {}).get(period, "")
                if val and val != default_val:
                    student.set_class_for(trimester, letter_day, period, val)
                elif (trimester in student.custom_schedule
                      and letter_day in student.custom_schedule[trimester]
                      and period in student.custom_schedule[trimester][letter_day]):
                    # Remove custom if it's the same as default or blank
                    del student.custom_schedule[trimester][letter_day][period]
            self.tracker.save_data()
            messagebox.showinfo("Success", f"Letter Day Schedule for {trimester} saved.")
            self.show_manage_student(student_name)

        ttkb.Button(edit_frame, text="💾 Save Letter Day Schedule", command=save_schedule, bootstyle="success").pack(pady=15)
        ttkb.Button(edit_frame, text="⬅ Back", command=lambda: self.show_manage_student(student_name), bootstyle="primary").pack()


    def edit_classes(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        edit_frame = ttkb.Frame(self.main_content)
        edit_frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttkb.Label(edit_frame, text=f"Enter Classes by Letter Day – {student.name}",
                   font=("Helvetica", 16, "bold"), foreground="white").pack(pady=10)

        trimester_var = tk.StringVar(value=get_current_trimester())
        ttkb.Label(edit_frame, text="Select Trimester:", foreground="white").pack(anchor="w")
        trimester_dropdown = ttkb.Combobox(
            edit_frame, textvariable=trimester_var,
            values=list(TRIMESTERS.keys()), state="readonly"
        )
        trimester_dropdown.pack(fill="x", pady=5)

        class_options = [
            "Language and Literacy (L&L)",
            "Mathematics",
            "Science",
            "Social Studies/Civics",
            "Art",
            "Gym",
            "Health",
            "Theatre",
            "Band",
            "Chorus",
            "Music",
            "World Language (Spanish)",
            "World Language (French)",
            "World Language (Mandarin)",
            "Instructional Technology",
            "Library Research",
            "Tech Ed",
            "Skills(WIN)",
        ]

        editor_container = ttkb.Frame(edit_frame)
        editor_container.pack(fill="both", expand=True)

        # For storing each combobox by (letter_day, period)
        comboboxes = {}

        def render_schedule_table():
            # Clear previous widgets
            for widget in editor_container.winfo_children():
                widget.destroy()

            # Header
            ttkb.Label(editor_container, text="Period", width=10, bootstyle="secondary").grid(row=0, column=0, padx=2, pady=2)
            for col, letter_day in enumerate(LETTER_DAYS):
                ttkb.Label(editor_container, text=letter_day, width=14, bootstyle="secondary").grid(row=0, column=col+1, padx=2, pady=2)

            # Table: Period rows x Letter day columns
            schedule_data = student.classes.get(trimester_var.get(), {})
            for row in range(1, 8):
                ttkb.Label(editor_container, text=f"Period {row}", width=10, bootstyle="secondary").grid(row=row, column=0, padx=2, pady=2)
                for col, letter_day in enumerate(LETTER_DAYS):
                    # Get current selection, fallback to blank
                    class_val = schedule_data.get(letter_day, {}).get(row, "")
                    var = tk.StringVar(value=class_val)
                    cb = ttkb.Combobox(
                        editor_container, textvariable=var,
                        values=[""] + class_options, state="readonly", width=16
                    )
                    cb.grid(row=row, column=col+1, padx=2, pady=2)
                    comboboxes[(letter_day, row)] = var

        # Bind trimester change to re-render table
        trimester_var.trace_add("write", lambda *_: render_schedule_table())
        render_schedule_table()

        def save_classes():
            selected = trimester_var.get()
            # Gather all selections into correct nested dict structure
            new_schedule = {}
            for letter_day in LETTER_DAYS:
                new_schedule[letter_day] = {}
                for period in range(1, 8):
                    val = comboboxes[(letter_day, period)].get()
                    if val:
                        new_schedule[letter_day][period] = val
            student.classes[selected] = new_schedule
            self.tracker.save_data()
            messagebox.showinfo("Success", f"Classes for {selected} saved.")
            self.show_portfolio(student_name)

        ttkb.Button(edit_frame, text="💾 Save Classes", command=save_classes, bootstyle="success").pack(pady=15)
        ttkb.Button(edit_frame, text="⬅ Back to Menu", command=lambda: self.show_student_profile(student_name), bootstyle="primary").pack()

    def edit_todos(self, student_name):
        self.clear_main_content()
        student = self.tracker.students.get(student_name)
        if not student:
            messagebox.showerror("Error", "Student not found.")
            return

        todo_frame = ttkb.Frame(self.main_content)
        todo_frame.pack(padx=20, pady=20, fill="both", expand=True)

        ttkb.Label(todo_frame, text=f"{student.name}'s Weekly To-Do List",
                   foreground="white", font=("Helvetica", 16, "bold")).pack(pady=10)

        todo_listbox = tk.Listbox(todo_frame, height=8, bg="#1E1E1E", fg="white", selectbackground="#2C2C2C", relief="flat", bd=1)
        for task in student.weekly_todos:
            todo_listbox.insert(tk.END, task)
        todo_listbox.pack(pady=10, fill="both", expand=True, padx=10)

        task_var = tk.StringVar()
        ttkb.Entry(todo_frame, textvariable=task_var).pack(pady=5, fill="x", padx=10)

        def add_task():
            t = task_var.get().strip()
            if t:
                student.weekly_todos.append(t)
                todo_listbox.insert(tk.END, t)
                task_var.set("")

        def del_task():
            sel = todo_listbox.curselection()
            if sel:
                student.weekly_todos.pop(sel[0])
                todo_listbox.delete(sel[0])

        btns = ttkb.Frame(todo_frame)
        btns.pack(pady=5)
        ttkb.Button(btns, text="Add Task", command=add_task, bootstyle="primary").pack(side="left", padx=5)
        ttkb.Button(btns, text="Delete Selected", command=del_task, bootstyle="danger").pack(side="left", padx=5)

        ttkb.Button(todo_frame, text="⬅ Back to Menu", command=lambda: self.show_student_profile(student_name), bootstyle="light").pack(pady=15)

    def generate_summary(self, student_name):
        if not student_name or student_name not in self.tracker.students:
            messagebox.showerror("Error", "Student not found.")
            return
        student = self.tracker.students[student_name]

        summary_window = ttkb.Toplevel(self.root)
        summary_window.title(f"{student.name}'s Behavior Summary")
        summary_window.geometry("600x500")
        summary_window.configure()

        ttkb.Label(
            summary_window,
            text=f"{student.name} - Behavior Summary",
            font=("Helvetica", 16, "bold"),
            foreground="white").pack(pady=10)

        frame = ttkb.Frame(summary_window, bootstyle="dark")
        frame.pack(fill="both", expand=True, padx=10, pady=10)

        output = tk.Text(frame, font=("Helvetica", 12), bg="#1E1E1E", fg="white", wrap="word")
        output.pack(padx=5, pady=5, fill="both", expand=True)

        output.tag_config("header", font=("Helvetica", 13, "bold"), foreground="white")

        total_pos = sum(1 for log in student.behavior_log if log["positive"])
        total_neg = sum(1 for log in student.behavior_log if not log["positive"])

        output.insert(tk.END, "📌 Totals\n\n", "header")
        output.insert(tk.END, f"Total Positive Behaviors: {total_pos}\n\n")
        output.insert(tk.END, f"Total Negative Behaviors: {total_neg}\n\n")

        types = {}
        by_date = {}
        by_period = {i: {"positive": 0, "negative": 0} for i in range(1, 8)}
        for log in student.behavior_log:
            types[log["type"]] = types.get(log["type"], 0) + 1
            by_date[log["timestamp"]] = by_date.get(log["timestamp"], 0) + 1
            p = log["period"]
            by_period[p]["positive" if log["positive"] else "negative"] += 1

        output.insert(tk.END, "🧠 Most Common Behavior Types\n\n", "header")
        if types:
            for btype, count in sorted(types.items(), key=lambda x: x[1], reverse=True):
                icon = "✅" if btype.lower() in ["on task", "participation", "helpfulness"] else "⚠️"
                output.insert(tk.END, f"{icon} {btype}: {count}\n")
        else:
            output.insert(tk.END, "No behavior entries.\n\n")

        output.insert(tk.END, "\n📆 Daily Breakdown\n\n", "header")
        for date, cnt in sorted(by_date.items()):
            output.insert(tk.END, f"{date}: {cnt} logged\n\n")

        output.insert(tk.END, "\n🕐 Period Breakdown\n\n", "header")
        for period, vals in by_period.items():
            output.insert(tk.END, f"Period {period}: ✅ {vals['positive']} | ⚠️ {vals['negative']}\n\n")

        output.config(state="disabled")

        ttkb.Button(summary_window, text="Close", bootstyle="secondary", command=summary_window.destroy).pack(pady=10)
        
    def show_settings(self):
        self.clear_main_content()
        ttkb.Label(self.main_content, text="Settings Page (Coming Soon)",
                  font=("Helvetica", 14), bootstyle="inverse-light").pack(pady=20)
        ttkb.Button(self.main_content, text="Restore Deleted Students",
                  bootstyle="primary", command=self.show_restore_deleted).pack(pady=10)

    def edit_behavior_entry(self, student_name, log_entry):
        new_desc = simpledialog.askstring("Edit Entry", "Update behavior description:", initialvalue=log_entry["description"])
        if new_desc:
            log_entry["description"] = new_desc
            self.tracker.save_data()
            self.show_full_log(student_name)

    def delete_behavior_entry(self, student_name, date_key, index):
        student = self.tracker.students[student_name]
        all_entries_for_day = [entry for entry in student.behavior_log if entry["timestamp"] == date_key]
        if index < len(all_entries_for_day):
            if messagebox.askyesno("Confirm", "Delete this entry?"):
                entry_to_remove = all_entries_for_day[index]
                student.behavior_log.remove(entry_to_remove)
                self.tracker.save_data()
                self.show_full_log(student_name)

    def pin_student(self, student_name):
        self.pinned_students.add(student_name)
        messagebox.showinfo("Pinned", f"{student_name} was added to My Students.")


    def logout(self):
        self.tracker.save_data()
        self.is_admin = False  # End admin session
        self.clear_main_content()  # Remove current screen
        self.show_login()  # Bring up login screen


if __name__== "__main__":
    import ttkbootstrap as ttkb
    root = ttkb.Window(themename="darkly")
    app = BehaviorApp(root)
    root.mainloop()
        
    
    

            
